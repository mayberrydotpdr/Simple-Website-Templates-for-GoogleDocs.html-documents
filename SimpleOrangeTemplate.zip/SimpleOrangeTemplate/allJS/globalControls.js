
//Global Controls
(function nHance (){
    for (myTheme=0; myTheme < document.all.length; myTheme++) {
        if (document.all[myTheme].tagName == 'html', 'body', 'div', 'article', 'section', 'aside', 'p', 'a', 'header', 'h1', 'h2', 'h3', 'h4', 'iframe') {
            with (document.all[myTheme].style) {
                if (backgroundColor=='#ccc') {
                    void (backgroundColor=document.bgColor)
                } else {
                  void(backgroundColor='#ccc')
                  }                                  
            }
        }
    }
}());

(function() {
    domList = [];
    var xyz = document.body.querySelectorAll('*'); 
    var index = 0; 
    for( index=0; index < xyz.length; index++ ) {
    	domList.push(xyz[index]);
	}

	for(var i=0; i<domList.length; i++){
	    //domList[i].style.color= '#000';
	    domList[i].style.backgroundColor= '#ccc';
	}
}());


