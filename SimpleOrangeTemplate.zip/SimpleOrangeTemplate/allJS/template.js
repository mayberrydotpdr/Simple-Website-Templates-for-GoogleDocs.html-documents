


(function() {
    aList = [];
    headingList = [];
    headingListToString = [];
    var a = document.body.querySelectorAll('A'); 
    var index = 0; 
    for( index=0; index < a.length; index++ ) {
        aList.push(a[index]);
    }

    for(var i=0; i<aList.length; i++){
        if (aList[i].href.includes('#h.')) {
            headingList.push(aList[i])
        }
    }

    for(var i=0; i<headingList.length; i++){
        headingList[i].style.display = 'none';
        headingHref = headingList[i].toString();
        theLink = headingList[i].textContent;
        concatEachAtag = '<li class="menuLiTags"><a href="' + headingHref + '" class="menuAtags">' + theLink + '</a></li>';
        headingListToString.push(concatEachAtag);
    }
}());



(function(){
    var newStyle = document.createElement('link'),
        newMenu = document.createElement('div'),
        newHeader = document.createElement('header'),
        newTitle = document.createElement('title'),
        newMeta = document.createElement('meta'),
        newFavicon = document.createElement('link');
    newStyle.id = 'styleSheet';
    newMenu.id = 'leftSideMenuId';
    newHeader.id = 'titleHeader';
    newMeta.id = 'newMetaTag';
    newFavicon.id = 'theNewFavicon';
    newMenu.innerHTML = '<center><img src="SimpleOrangeTemplate/templateImages/menuTopImage.png"></center><div id="wrapper"><ul class="menuListULtag">' + headingListToString + '</ul><div><div id="menuBurgerIcon"><img src="SimpleOrangeTemplate/templateImages/menuBurger.png" alt="Menu"></div>';
    
    document.getElementsByTagName("HEAD")[0].appendChild(newStyle);
    document.getElementsByTagName("HEAD")[0].appendChild(newTitle);
    document.getElementsByTagName("HEAD")[0].appendChild(newMeta);
    document.getElementsByTagName("HEAD")[0].appendChild(newFavicon);
    document.getElementsByTagName("BODY")[0].appendChild(newMenu);
    document.getElementsByTagName("h1")[0].appendChild(newHeader);
    var source = document.getElementById("styleSheet"),
        metaDescription = document.getElementById("newMetaTag"),
        favicon = document.getElementById("theNewFavicon"),
        slideInAndOut = document.getElementById("leftSideMenuId"),
        firstPdescription = document.getElementsByTagName("p")[0].textContent,
        theTitle = document.getElementsByTagName("h1")[0].textContent;
    newTitle.innerHTML = theTitle;
    newHeader.innerHTML = '<center><div id="titleFont">' + theTitle + '</div></center><span id="logo"><img src="SimpleOrangeTemplate/templateImages/logo.png"></span>';
    metaDescription.setAttribute('name', 'description');
    metaDescription.setAttribute('content', firstPdescription);
    favicon.setAttribute('href', 'SimpleOrangeTemplate/templateImages/favicon.png');
    favicon.setAttribute('rel', 'icon');
    favicon.setAttribute('type', 'image/x-icon');
    source.setAttribute('rel', 'stylesheet');
    source.setAttribute('type', 'text/css');
    source.setAttribute('href', 'SimpleOrangeTemplate/stylesheets/style.css');
    slideInAndOut.setAttribute('class', 'leftSideMenu');
    slideInAndOut.setAttribute('onclick', 'viewMenu()');
}());

function viewMenu() {
    var slideInAndOut = document.getElementById("leftSideMenuId");

    if (slideInAndOut.classList) { 
        slideInAndOut.classList.toggle("slideIn");
    } else {
        var classes = slideInAndOut.className.split(" ");
        var i = classes.indexOf("slideIn");

        if (i >= 0) 
            classes.splice(i, 1);
        else 
            classes.push("slideIn");
            slideInAndOut.className = classes.join(" "); 
    }
}



/*






(function() {
    aList = [];
    aListString = [];
    var a = document.body.querySelectorAll('A'); 
    var index = 0; 
    for( index=0; index < a.length; index++ ) {
        aList.push(a[index]);
    }

    var indexS = 0; 
    for( indexS=0; indexS < a.length; indexS++ ) {
        a.toString();
        aListString.push(a[indexS]);
    }

    for(var i=0; i<aList.length; i++){
        aList[i].style.backgroundColor= 'green';
        //x[i] = aList[i].toString();
    }
    console.log(typeof(aListString[0]));
}());



var myArray = ['adam', 'bianca', 'cat', 'dennis'];
var myFunc = function (letter) {
    for (var i = 0; i < letter.length; i += 1) {
        // Use the index i here
        console.log(letter[i].charAt(0));
    }
}

// Call your function, passing in the array you defined:
myFunc(myArray);
// a
// b
// c
// d


aList.toString();
console.log(aList);









var myArray = ['adam', 'bianca', 'cat', 'dennis'];
var myFunc = function (letter) {
    for (var i = 0; i < letter.length; i += 1) {
        // Use the index i here
        console.log(letter[i].charAt(0));
    }
}

// Call your function, passing in the array you defined:
myFunc(myArray);
// a
// b
// c
// d



    console.log(aListString[0].includes('#h.1'));



        if (aList[i][includes("#h.")]){
            console.log('yes');
        } else {
        aList[i].style.backgroundColor= 'green';
            console.log('no');
        }




const items = ['item1', 'item2', 'item3'];
const copy = [];

items.forEach(function(item){
  copy.push(item)
});




function logArrayElements(element, index, array) {
  console.log('a[' + index + '] = ' + element);
}

// Notice that index 2 is skipped since there is no item at
// that position in the array.
[2, 5, , 9].forEach(logArrayElements);
// logs:
// a[0] = 2
// a[1] = 5
// a[3] = 9




*/











































